/* 
 * Copyright 2025 Finlay Scott. Distributed under the GPL 2 or later
 * Maintainer: Finlay Scott
 */

// Add all the includes here

#include "simple_array.h"
#include "simple_array_3D.h"
#include "find_effort.h"

// [[Rcpp::depends(RcppEigen)]]
// [[Rcpp::plugins(cpp17)]]

