run_cpp_tests("tandoori")
